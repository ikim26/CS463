//Author: Isaac Kim
//CS 463
//Professor Mark Snyder
//April 8, 2023

//class for player
public class Player extends Thread{
    //player attributes
    private Chair chair;
    private String id;
    private MCRoom mcroom;

    //default constructor (takes in int for id and makes string name out of it)
    public Player(int id, MCRoom mcroom){
        this.id = "P"+id;
        this.mcroom = mcroom;
    }

    //getter for id
    public String getId(){
        return this.id
    }

    //getter and setter for chair
    public Chair getChair(){
        return this.chair;
    }

    public void setChair(Chair chair){
        this.chair = chair;
    }

    //method to find chair once music stops
    //synchronized bc this is the method that uses concurrency (players looking for chairs at the same time)
    public synchronized Chair findChair(){
        int index = 0;
        //find first available chair
        while(index < mcroom.getChairs().size()){

            //if chair we try to sit in is free (not taken)
            if(!mcroom.getChairs().get(index).isTaken()){

                //set chair to taken (sit in chair)
                mcroom.getChairs().get(index).setStatus(true);

                //return the chair we sit in
                return mcroom.getChairs().get(index);
            }
            index++;
        }
        //if we reach here, we looked at all chairs, but all were taken
        return null;
    }

    //run method
    public void run(){
        //first wait 
        try {
            wait(); //(this is essentially "playing musical chairs" when music is on)
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        //once we reach here, music is turned off. Find a chair!
        setChair(findChair());

        //if we didn't find a chair, send player id to eliminated
        if(getChair() == null){
            mcroom.setEliminated(this.id);
        }
        //otherwise, print we found a chair
        else{
            System.out.println(this.id + " sat in " + this.chair.getID());
        }
    }
}