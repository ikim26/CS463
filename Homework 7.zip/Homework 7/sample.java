import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.;

public class MusicalChairSimulation {

    private static final int NUM_PLAYERS = 5;
    private static final int NUM_CHAIRS = 3;

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(NUM_PLAYERS);
        Phaser phaser = new Phaser(NUM_PLAYERS + 1);

        List<Future<Player>> playerFutures = new ArrayList<>();
        for (int i = 1; i <= NUM_PLAYERS; i++) {
            playerFutures.add(executor.submit(new Player(i, phaser)));
        }

        for (int round = 1; round <= NUM_CHAIRS; round++) {
            System.out.println("Starting round " + round);
            phaser.arriveAndAwaitAdvance();
            System.out.println("Music stopped for round " + round);
            List<Player> players = new ArrayList<>();
            for (Future<Player> future : playerFutures) {
                try {
                    Player player = future.get();
                    if (!player.isOut()) {
                        players.add(player);
                    }
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
            if (players.size() <= 1) {
                System.out.println("Game over! Player " + players.get(0).getId() + " wins!");
                break;
            }
            int chairIndex = ThreadLocalRandom.current().nextInt(players.size());
            Player playerOut = players.get(chairIndex);
            playerOut.setOut(true);
            System.out.println("Player " + playerOut.getId() + " is out!");
            phaser.arriveAndAwaitAdvance();
        }

        executor.shutdown();
    }

    private static class Player implements Callable<Player> {

        private final int id;
        private final Phaser phaser;
        private boolean out;

        public Player(int id, Phaser phaser) {
            this.id = id;
            this.phaser = phaser;
            this.out = false;
            this.phaser.register();
        }

        public int getId() {
            return id;
        }

        public boolean isOut() {
            return out;
        }

        public void setOut(boolean out) {
            this.out = out;
        }

        @Override
        public Player call() throws Exception {
            while (true) {
                System.out.println("Player " + id + " is dancing");
                phaser.arriveAndAwaitAdvance();
                if (out) {
                    System.out.println("Player " + id + " is out");
                    phaser.arriveAndDeregister();
                    return this;
                }
                System.out.println("Player " + id + " is sitting");
                phaser.arriveAndAwaitAdvance();
            }
        }
    }

}
