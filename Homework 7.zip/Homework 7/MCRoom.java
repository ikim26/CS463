//Author: Isaac Kim
//CS 463
//Professor Mark Snyder
//April 8, 2023

//class for shared resource for emcee and players (simulate the musical chair room)
public class MCRoom{
	//class vars
	private ArrayList<Player> players;
    private ArrayList<Chair> chairs;
    private String eliminated;

	//default constructor
	public MCRoom(ArrayList<Player> players, ArrayList<Chair> chairs){
		this.players = players;
		this.chairs = chairs;
	}

	//getter and setter for players
	public ArrayList<Player> getPlayers(){
		return this.players;
	}

	public void setPlayers(ArrayList<Player> players){
		this.players = players;
	}

	//getter and setter for chairs
	public ArrayList<Chair> getChairs(){
		return this.chairs;
	}

	public void setChairs(ArrayList<Chair> chairs){
		this.chairs = chairs;
	}

	//getter and setter for eliminated player
	public String getEliminated(){
		return this.eliminated;
	}

	public void setEliminated(String id){
		this.eliminated = eliminated;
	}
}