//Author: Isaac Kim
//CS 463
//Professor Mark Snyder
//April 8, 2023

//class for player
public class Emcee extends Thread{
	//class vars
	private MCRoom mcroom;

	//default constructor
	public Emcee(MCRoom mcroom){
		this.MCRoom = mcroom;
	}

	//run method
	public void run(){
		/*
        //play as many rounds as there are chairs
        for(int i = 1; i < num_chairs; i++){
            //print round number
            System.out.println("round "+i);

        }*/
	}
}