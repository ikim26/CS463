//Author: Isaac Kim
//CS 463
//Professor Mark Snyder
//April 8, 2023

//class for chair
public class Chair{
    private String id;
    private boolean taken;

    //default construstor (takes in int for id and makes string name out of it)
    public Chair(int id){
    	this.id = "C"+id;
    	this.taken = false;
    }

    //getter for Chair id
    public String getID(){
    	return this.id;
    }

    //getter and setter for taken status
    public boolean isTaken(){
    	return this.taken;
    }

    public void setStatus(boolean status){
    	this.taken = status;
    }

}
